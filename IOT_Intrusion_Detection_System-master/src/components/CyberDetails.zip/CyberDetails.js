import React, { useEffect, useState } from "react";
import axios from "axios";

const CyberDetails = () => {
  const [attackDetails, setAttackDetails] = useState(null);

  useEffect(() => {
    axios.get("http://127.0.0.1:5001/latest_cyber_attack")
      .then((res) => setAttackDetails(res.data))
      .catch(() => setAttackDetails(null));
  }, []);

  return (
    <div className="min-h-screen bg-red-900 text-white p-6">
      <h2 className="text-3xl font-bold">New Cyber Attack Details</h2>
      {attackDetails ? (
        <div className="mt-4 p-4 bg-gray-800 rounded-lg shadow-lg">
          <p><strong>Attack Type:</strong> {attackDetails.attack}</p>
          <p><strong>Protocol:</strong> {attackDetails.proto}</p>
          <p><strong>Origin Bytes:</strong> {attackDetails.orig_bytes}</p>
          <p><strong>Response Bytes:</strong> {attackDetails.resp_bytes}</p>
          <p><strong>Timestamp:</strong> {attackDetails.timestamp}</p>
        </div>
      ) : (
        <p className="text-gray-300">No attack details available.</p>
      )}
    </div>
  );
};

export default CyberDetails;
