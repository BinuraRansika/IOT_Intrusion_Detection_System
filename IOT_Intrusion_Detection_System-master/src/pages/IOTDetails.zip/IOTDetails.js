import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from "chart.js";

// Register chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const IOTDetails = () => {
  const [attackDetails, setAttackDetails] = useState([]);
  const [error, setError] = useState(null);
  const [terminalOutput, setTerminalOutput] = useState([]);
  const terminalRef = useRef(null);
  
  const [iotData, setIotData] = useState({
    labels: [],
    datasets: [{
      label: 'Attack Frequency',
      data: [],
      borderColor: 'rgba(75, 192, 192, 1)',
      fill: false,
    }],
  });

  useEffect(() => {
    // Fetch attack data including detailed features
    axios.get("http://127.0.0.1:5005/iot_attack_details")
      .then((res) => {
        setAttackDetails(res.data.attacks);
        updateChartData(res.data.attacks);  // Update chart data
      })
      .catch((err) => {
        console.error("Error fetching attack details:", err);
        setError("No attack details available.");
      });

    // Simulate real-time packet capturing
    const interval = setInterval(() => {
      fetchTerminalData();
    }, 5000); // Fetch new data every 5 seconds

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  // Function to update chart with attack data
  const updateChartData = (data) => {
    const labels = data.map(item => item.timestamp);
    const frequencies = data.map(item => item.attack);  // Adjust if needed (e.g., count frequencies)
    
    setIotData({
      labels: labels,
      datasets: [{
        label: 'Attack Frequency',
        data: frequencies,
        borderColor: 'rgba(75, 192, 192, 1)',
        fill: false,
      }],
    });
  };

  // Function to simulate terminal data fetching
  const fetchTerminalData = () => {
    axios.get("http://127.0.0.1:5005/latest_iot_attack")
      .then((res) => {
        const newEntry = `${new Date().toLocaleTimeString()} - ${res.data.attack}`;
        setTerminalOutput((prev) => [...prev, newEntry]);
        if (terminalRef.current) {
          terminalRef.current.scrollTop = terminalRef.current.scrollHeight; // Auto-scroll terminal
        }
      })
      .catch((err) => {
        console.error("Error fetching terminal data:", err);
      });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h2 className="text-2xl font-bold">IoT Attack Details</h2>

      {/* Display error if no data */}
      {error ? (
        <div className="text-red-400 mt-4">{error}</div>
      ) : (
        <>
          {/* Attack Data Chart */}
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Attack Frequency (Real-Time)</h3>
            <Line data={iotData} />
          </div>

          {/* Attack History Table */}
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Attack History</h3>
            <table className="w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Timestamp</th>
                  <th className="px-4 py-2 border">Attack Type</th>
                  {/* Add more columns for feature details */}
                  <th className="px-4 py-2 border">Duration</th>
                  <th className="px-4 py-2 border">Proto</th>
                  <th className="px-4 py-2 border">Orig Bytes</th>
                  <th className="px-4 py-2 border">Resp Bytes</th>
                  <th className="px-4 py-2 border">Missed Bytes</th>
                  <th className="px-4 py-2 border">Orig PKTs</th>
                  <th className="px-4 py-2 border">Resp PKTs</th>
                  <th className="px-4 py-2 border">Conn State</th>
                  <th className="px-4 py-2 border">History</th>
                  <th className="px-4 py-2 border">Service</th>
                </tr>
              </thead>
              <tbody>
                {attackDetails.map((attack, index) => (
                  <tr key={index}>
                    <td className="px-4 py-2 border">{attack.timestamp}</td>
                    <td className="px-4 py-2 border">{attack.attack}</td>
                    {/* Display the feature details */}
                    <td className="px-4 py-2 border">{attack.features.duration}</td>
                    <td className="px-4 py-2 border">{attack.features.proto}</td>
                    <td className="px-4 py-2 border">{attack.features.orig_bytes}</td>
                    <td className="px-4 py-2 border">{attack.features.resp_bytes}</td>
                    <td className="px-4 py-2 border">{attack.features.missed_bytes}</td>
                    <td className="px-4 py-2 border">{attack.features.orig_pkts}</td>
                    <td className="px-4 py-2 border">{attack.features.resp_pkts}</td>
                    <td className="px-4 py-2 border">{attack.features.conn_state}</td>
                    <td className="px-4 py-2 border">{attack.features.history}</td>
                    <td className="px-4 py-2 border">{attack.features.service}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Command Prompt-like Terminal */}
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Packet Capture Terminal</h3>
            <div
              ref={terminalRef}
              className="bg-black text-white p-4 rounded-md"
              style={{ height: '250px', overflowY: 'scroll', fontFamily: 'Courier New, monospace' }}
            >
              {terminalOutput.length > 0 ? (
                terminalOutput.map((entry, index) => <div key={index}>{entry}</div>)
              ) : (
                <div>No packets received yet.</div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default IOTDetails;