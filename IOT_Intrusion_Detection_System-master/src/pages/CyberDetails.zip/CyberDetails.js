import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from "chart.js";

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const CyberDetails = () => {
  const [attackDetails, setAttackDetails] = useState([]);
  const [error, setError] = useState(null);
  const [terminalOutput, setTerminalOutput] = useState([]);
  const terminalRef = useRef(null);

  const [cyberData, setCyberData] = useState({
    labels: [],
    datasets: [
      {
        label: "Attack Frequency",
        data: [],
        borderColor: "rgba(255, 99, 132, 1)",
        backgroundColor: "rgba(255, 99, 132, 0.2)",
        fill: true,
      },
    ],
  });

  useEffect(() => {
    // Fetch attack data
    const fetchAttackDetails = async () => {
      try {
        const res = await axios.get("http://127.0.0.1:5006/cicids_attack_details");
        if (res.data.attacks && res.data.attacks.length > 0) {
          setAttackDetails(res.data.attacks);
          updateChartData(res.data.attacks); // Update chart data
        } else {
          setError("No attack details available.");
        }
      } catch (err) {
        console.error("Error fetching attack details:", err);
        setError("Error fetching attack details.");
      }
    };

    // Simulate real-time packet capturing
    const fetchTerminalData = async () => {
      try {
        const res = await axios.get("http://127.0.0.1:5006/latest_cicids_attack");
        if (res.data.attack) {
          const newEntry = `${new Date().toLocaleTimeString()} - ${res.data.attack}`;
          setTerminalOutput((prev) => [...prev, newEntry]);

          // Auto-scroll terminal
          if (terminalRef.current) {
            terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
          }
        }
      } catch (err) {
        console.error("Error fetching terminal data:", err);
      }
    };

    fetchAttackDetails();
    fetchTerminalData();

    const interval = setInterval(() => {
      fetchAttackDetails();
      fetchTerminalData();
    }, 5000); // Refresh every 5 seconds

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  // Function to update chart with attack data
  const updateChartData = (data) => {
    if (!data || data.length === 0) {
      setError("No attack details available.");
      return;
    }

    const labels = data.map((item) => item.timestamp);
    const attackCounts = data.map(() => 1); // Simple count per attack event

    setCyberData({
      labels: labels,
      datasets: [
        {
          label: "Attack Frequency",
          data: attackCounts,
          borderColor: "rgba(255, 99, 132, 1)",
          backgroundColor: "rgba(255, 99, 132, 0.2)",
          fill: true,
        },
      ],
    });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h2 className="text-2xl font-bold">Cyber Attack Details</h2>

      {/* Display error if no data */}
      {error ? (
        <div className="text-red-400 mt-4">{error}</div>
      ) : (
        <>
          {/* Attack Data Chart */}
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Attack Frequency (Real-Time)</h3>
            <Line data={cyberData} />
          </div>

          {/* Attack History Table */}
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Attack History</h3>
            <table className="w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Timestamp</th>
                  <th className="px-4 py-2 border">Attack Type</th>
                </tr>
              </thead>
              <tbody>
                {attackDetails.length > 0 ? (
                  attackDetails.map((attack, index) => (
                    <tr key={index}>
                      <td className="px-4 py-2 border">{attack.timestamp}</td>
                      <td className="px-4 py-2 border">{attack.attack}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td className="px-4 py-2 border text-center" colSpan="2">
                      No attack data available.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Command Prompt-like Terminal */}
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Packet Capture Terminal</h3>
            <div
              ref={terminalRef}
              className="bg-black text-white p-4 rounded-md"
              style={{ height: "250px", overflowY: "scroll", fontFamily: "Courier New, monospace" }}
            >
              {terminalOutput.length > 0 ? (
                terminalOutput.map((entry, index) => <div key={index}>{entry}</div>)
              ) : (
                <div>No packets received yet.</div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default CyberDetails;
