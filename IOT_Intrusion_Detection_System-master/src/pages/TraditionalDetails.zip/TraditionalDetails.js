import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from "chart.js";

// Register chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const TraditionalDetails = () => {
  const [attackDetails, setAttackDetails] = useState([]);
  const [error, setError] = useState(null);
  const [terminalOutput, setTerminalOutput] = useState([]);
  const terminalRef = useRef(null);

  const [traditionalData, setTraditionalData] = useState({
    labels: [],
    datasets: [{
      label: 'Attack Frequency',
      data: [],
      borderColor: 'rgba(54, 162, 235, 1)',
      fill: false,
    }],
  });

  useEffect(() => {
    axios.get("http://127.0.0.1:5007/kdd_attack_details")
      .then((res) => {
        setAttackDetails(res.data.attacks);
        updateChartData(res.data.attacks);
      })
      .catch(() => setError("No attack details available."));

    const interval = setInterval(() => {
      fetchTerminalData();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const updateChartData = (data) => {
    const labels = data.map(item => item.timestamp);
    const frequencies = data.map(item => item.attack);

    setTraditionalData({
      labels: labels,
      datasets: [{
        label: 'Attack Frequency',
        data: frequencies,
        borderColor: 'rgba(54, 162, 235, 1)',
        fill: false,
      }],
    });
  };

  const fetchTerminalData = () => {
    axios.get("http://127.0.0.1:5007/latest_kdd_attack")
      .then((res) => {
        const newEntry = `${new Date().toLocaleTimeString()} - ${res.data.attack}`;
        setTerminalOutput((prev) => [...prev, newEntry]);
        if (terminalRef.current) {
          terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
        }
      })
      .catch(() => {});
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h2 className="text-2xl font-bold">Traditional Attack Details</h2>

      {error ? (
        <div className="text-red-400 mt-4">{error}</div>
      ) : (
        <>
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Attack Frequency (Real-Time)</h3>
            <Line data={traditionalData} />
          </div>

          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Attack History</h3>
            <table className="w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Timestamp</th>
                  <th className="px-4 py-2 border">Attack Type</th>
                </tr>
              </thead>
              <tbody>
                {attackDetails.map((attack, index) => (
                  <tr key={index}>
                    <td className="px-4 py-2 border">{attack.timestamp}</td>
                    <td className="px-4 py-2 border">{attack.attack}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4">Packet Capture Terminal</h3>
            <div ref={terminalRef} className="bg-black text-white p-4 rounded-md" style={{ height: '250px', overflowY: 'scroll', fontFamily: 'Courier New, monospace' }}>
              {terminalOutput.length > 0 ? (
                terminalOutput.map((entry, index) => <div key={index}>{entry}</div>)
              ) : (
                <div>No packets received yet.</div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default TraditionalDetails;
